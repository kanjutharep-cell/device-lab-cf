# device-lab (cloudflare workers)

lab monitoring device sendiri. agent di hp kedua, dashboard di browser.

## Setup lokal

    npm install
    npx wrangler dev

## Deploy

    npm install
    npx wrangler login
    npx wrangler deploy

## Atau via Cloudflare Dashboard

1. push repo ke github
2. dashboard cloudflare -> Workers & Pages -> Create -> Connect to Git
3. pilih repo ini
4. deploy

## URL setelah deploy

- dashboard: https://device-lab.USERNAME.workers.dev/
- agent:     https://device-lab.USERNAME.workers.dev/agent.html

## Auth

edit `AUTH_TOKEN` di `wrangler.toml` atau via dashboard -> Settings -> Variables.

## Catatan

versi ini gak punya recording/replay/export (workers gak ada filesystem).
buat fitur itu pakai versi termux (`device-lab`).
