// ═══════════════════════════════════════
// device-lab — full cloudflare worker
// relay + R2 recording + geofence + telegram
// ═══════════════════════════════════════

function parseUsers(env) {
  try {
    if (env.USERS_JSON) return JSON.parse(env.USERS_JSON);
  } catch(_) {}
  // fallback: single token
  return { 'default': env.AUTH_TOKEN || '' };
}

function getUserFromToken(token, users) {
  for (const [user, tok] of Object.entries(users)) {
    if (tok === token) return user;
  }
  return null;
}

function haversine(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = x => x * Math.PI / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a = Math.sin(dLat/2)**2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

async function sendTelegram(env, text) {
  if (!env.TELEGRAM_BOT_TOKEN || !env.TELEGRAM_CHAT_ID) return;
  try {
    await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: env.TELEGRAM_CHAT_ID,
        text,
        parse_mode: 'Markdown'
      })
    });
  } catch(e) {}
}

export class Relay {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    this.agents = new Map();
    this.dashboards = new Set();
    this.frameIdx = new Map();
    this.lastGeofenceState = new Map();
    this.lastLowBattery = new Map();
    this.fenceCache = null;

    // load fence persistent
    this.state.blockConcurrencyWhile(async () => {
      try {
        const stored = await this.state.storage.get('fence');
        if (stored) this.fenceCache = stored;
      } catch(_) {}
    });
  }

  async fetch(request) {
    const url = new URL(request.url);

    // HTTP endpoint internal dari DO
    if (url.pathname === '/state') {
      return new Response(JSON.stringify({
        agents: [...this.agents.keys()]
      }), { headers: { 'Content-Type': 'application/json' } });
    }

    // websocket
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    server.accept();

    let role = null, agentId = null;

    server.addEventListener('message', async (e) => {
      let msg;
      try { msg = JSON.parse(e.data); } catch { return; }

      if (msg.type === 'register') {
        const users = parseUsers(this.env);
        const user = getUserFromToken(msg.token, users);
        if (!user) {
          try { server.send(JSON.stringify({ type: 'error', msg: 'invalid token' })); } catch(_) {}
          server.close();
          return;
        }
        role = msg.role;
        if (role === 'agent') {
          agentId = msg.id || ('agent-' + Date.now());
          this.agents.set(agentId, { ws: server, user });
          this.frameIdx.set(agentId, this.frameIdx.get(agentId) || 0);
          this.broadcastDash({ type: 'agent-online', id: agentId, info: msg.info || {}, user });
          sendTelegram(this.env, `🟢 agent online: \`${agentId}\` (user: ${user})`);
        } else if (role === 'dashboard') {
          this.dashboards.add({ ws: server, user });
          const visible = [...this.agents.entries()]
            .filter(([_, a]) => a.user === user)
            .map(([id]) => id);
          try {
            server.send(JSON.stringify({
              type: 'agent-list',
              agents: visible
            }));
            server.send(JSON.stringify({
              type: 'geofence',
              fence: this.getFence()
            }));
            server.send(JSON.stringify({ type: 'user', user }));
          } catch(_) {}
        }
        return;
      }

      if (role === 'dashboard' && msg.type === 'command') {
        const t = this.agents.get(msg.target);
        if (t && t.ws.readyState === 1) {
          try { t.ws.send(JSON.stringify({ type: 'command', cmd: msg.cmd, args: msg.args || {} })); } catch(_) {}
        }
        return;
      }

      if (role === 'dashboard' && msg.type === 'set-geofence') {
        this.setFence(msg.fence && msg.fence.lat ? msg.fence : null);
        this.broadcastDash({ type: 'geofence', fence: this.getFence() });
        return;
      }

      if (role === 'agent') {
        // simpen ke R2
        if (this.env.RECORDINGS) {
          this.persist(agentId, msg).catch(() => {});
        }
        const agentEntry = this.agents.get(agentId);
        const ownerUser = agentEntry ? agentEntry.user : null;

        // geofence check
        if (msg.type === 'telemetry' && msg.location) {
          this.checkGeofence(agentId, msg.location.lat, msg.location.lon);
          // low battery check
          if (msg.battery && msg.battery.level < 15 && !msg.battery.charging) {
            const last = this.lastLowBattery.get(agentId) || 0;
            if (Date.now() - last > 600000) {
              this.lastLowBattery.set(agentId, Date.now());
              sendTelegram(this.env, `🔋 *Low battery* pada \`${agentId}\`: ${msg.battery.level}%`);
            }
          }
        }

        this.broadcastDash({ ...msg, id: agentId }, ownerUser);
      }
    });

    server.addEventListener('close', () => {
      if (role === 'agent' && agentId) {
        const a = this.agents.get(agentId);
        this.agents.delete(agentId);
        this.broadcastDash({ type: 'agent-offline', id: agentId }, a ? a.user : null);
        sendTelegram(this.env, `🔴 agent offline: \`${agentId}\``);
      }
      if (role === 'dashboard') {
        for (const d of this.dashboards) {
          if (d.ws === server) this.dashboards.delete(d);
        }
      }
    });

    return new Response(null, { status: 101, webSocket: client });
  }

  async persist(agentId, msg) {
    const date = new Date().toISOString().slice(0, 10);
    const key = `${agentId}/${date}`;

    if (msg.type === 'frame') {
      const b64 = msg.data.split(',')[1];
      const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      const idx = String(this.frameIdx.get(agentId) || 0).padStart(6, '0');
      this.frameIdx.set(agentId, (this.frameIdx.get(agentId) || 0) + 1);
      await this.env.RECORDINGS.put(`${key}/frames/frame_${idx}.jpg`, bin, {
        httpMetadata: { contentType: 'image/jpeg' }
      });
    } else if (msg.type === 'screenshot') {
      const b64 = msg.data.split(',')[1];
      const bin = Uint8Array.from(atob(b64), c => c.charCodeAt(0));
      await this.env.RECORDINGS.put(`${key}/screenshots/shot_${Date.now()}.jpg`, bin, {
        httpMetadata: { contentType: 'image/jpeg' }
      });
    } else if (msg.type === 'telemetry') {
      const existing = await this.env.RECORDINGS.get(`${key}/telemetry.jsonl`);
      const prev = existing ? await existing.text() : '';
      await this.env.RECORDINGS.put(`${key}/telemetry.jsonl`, prev + JSON.stringify(msg) + '\n');
    } else if (msg.type === 'audio') {
      const existing = await this.env.RECORDINGS.get(`${key}/audio.b64`);
      const prev = existing ? await existing.text() : '';
      await this.env.RECORDINGS.put(`${key}/audio.b64`, prev + msg.data + '\n');
    }
  }

  getFence() {
    if (this.fenceCache) return this.fenceCache;
    const lat = parseFloat(this.env.GEOFENCE_LAT);
    const lon = parseFloat(this.env.GEOFENCE_LON);
    const radius = parseFloat(this.env.GEOFENCE_RADIUS);
    if (!lat || !lon || !radius) return null;
    return { lat, lon, radius };
  }

  setFence(fence) {
    if (!fence || !fence.lat) {
      this.fenceCache = null;
      this.state.storage.delete('fence').catch(() => {});
      return;
    }
    this.fenceCache = fence;
    this.state.storage.put('fence', fence).catch(() => {});
  }

  checkGeofence(agentId, lat, lon) {
    const fence = this.getFence();
    if (!fence) return;
    const dist = haversine(lat, lon, fence.lat, fence.lon);
    const inside = dist <= fence.radius;
    const prev = this.lastGeofenceState.get(agentId);
    if (prev !== undefined && prev !== inside) {
      const event = inside ? 'enter' : 'exit';
      const alert = { agentId, event, distance: Math.round(dist), radius: fence.radius, lat, lon, ts: Date.now() };
      this.broadcastDash({ type: 'geofence-alert', ...alert });
      sendTelegram(this.env, `⚠ *Geofence ${event}* pada \`${agentId}\` — ${Math.round(dist)}m dari pusat`);
    }
    this.lastGeofenceState.set(agentId, inside);
  }

  broadcastDash(msg, onlyUser) {
    const data = JSON.stringify(msg);
    for (const d of this.dashboards) {
      if (d.ws.readyState !== 1) continue;
      if (onlyUser && d.user !== onlyUser) continue;
      try { d.ws.send(data); } catch(_) {}
    }
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.headers.get('Upgrade') === 'websocket') {
      const id = env.RELAY.idFromName('main');
      const stub = env.RELAY.get(id);
      return stub.fetch(request);
    }

    if (url.pathname === '/config') {
      return new Response(JSON.stringify({
        ws: 'wss://' + url.host,
        agentUrl: 'https://' + url.host + '/agent.html',
        token: env.AUTH_TOKEN
      }), {
        headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }
      });
    }

    // sessions list — dari R2
    if (url.pathname === '/sessions' && env.RECORDINGS) {
      const listed = await env.RECORDINGS.list({ delimiter: '/' });
      const sessions = (listed.delimitedPrefixes || []).map(p => p.replace(/\/$/, ''));
      return new Response(JSON.stringify(sessions), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // list dates per agent
    if (url.pathname.startsWith('/dates/') && env.RECORDINGS) {
      const agent = url.pathname.slice(7);
      const listed = await env.RECORDINGS.list({ prefix: agent + '/', delimiter: '/' });
      const dates = (listed.delimitedPrefixes || []).map(p => p.replace(agent + '/', '').replace(/\/$/, ''));
      return new Response(JSON.stringify(dates), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // replay frame list
    if (url.pathname.startsWith('/replay/') && env.RECORDINGS) {
      const parts = url.pathname.slice(8).split('/');
      const prefix = parts.join('/') + '/frames/';
      const listed = await env.RECORDINGS.list({ prefix });
      const frames = listed.objects
        .filter(o => o.key.endsWith('.jpg'))
        .sort((a, b) => a.key.localeCompare(b.key))
        .map(o => '/' + o.key);
      return new Response(JSON.stringify({ frames }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // serve file dari R2 (frame/screenshot/telemetry/audio)
    if (env.RECORDINGS) {
      const key = url.pathname.slice(1);
      const obj = await env.RECORDINGS.get(key);
      if (obj) {
        return new Response(obj.body, {
          headers: {
            'Content-Type': obj.httpMetadata?.contentType || 'application/octet-stream',
            'Cache-Control': 'public, max-age=3600'
          }
        });
      }
    }

    // geofence get
    if (url.pathname === '/geofence' && request.method === 'GET') {
      const id = env.RELAY.idFromName('main');
      const stub = env.RELAY.get(id);
      return stub.fetch(new Request('http://x/state'));
    }

    return env.ASSETS.fetch(request);
  }
};
